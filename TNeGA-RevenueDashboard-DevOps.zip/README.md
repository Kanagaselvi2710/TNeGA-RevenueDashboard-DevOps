
# TNeGA-RevenueDashboard-DevOps
Our Voice, Our Rights — Tamil Nadu Revenue Dashboard
Built by: Kanagaselvi R

## What this project does
- Fetches real dataset records from data.gov.in (GST / revenue related dataset).
- Attempts to filter records for Tamil Nadu and visualizes year-wise values using two charts (bar + line).
- Simple Flask app intended for PythonAnywhere deployment.

## Setup (local)
1. Create and activate a Python virtual environment (recommended)
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. **Set your API key** as an environment variable (important):
   ```bash
   export DATA_GOV_API_KEY='YOUR_API_KEY_HERE'
   ```
3. Run the app:
   ```bash
   python app.py
   ```
4. Open http://localhost:5000 and click "Load Data".

## Deployment (PythonAnywhere)
- Create an account at https://www.pythonanywhere.com
- Upload project files (use the web UI or git)
- In the Web app settings, point WSGI to this Flask app and add the environment variable `DATA_GOV_API_KEY` with your API key.
- Reload the web app and open the public URL.

## Notes
- For security, never hard-code your API key into files pushed to public GitHub. Use environment variables on PythonAnywhere.
- Dataset field names vary; this demo attempts to select useful numeric fields for plotting.
