
import os
from flask import Flask, render_template, jsonify, request
import requests

app = Flask(__name__)

# Read API key from environment variable for security
API_KEY = os.environ.get("DATA_GOV_API_KEY", "")

# Resource endpoint for GST year-wise dataset (from data.gov.in catalog)
RESOURCE_ID = "14613c4e-5ab0-4705-b440-e4e49ae345de"
BASE_URL = f"https://api.data.gov.in/resource/{RESOURCE_ID}"

@app.route('/api/data')
def get_data():
    # Query params - using format=json and limit to 200 records
    params = {
        "api-key": API_KEY,
        "format": "json",
        "limit": 200
    }
    try:
        r = requests.get(BASE_URL, params=params, timeout=20)
        r.raise_for_status()
        payload = r.json()
        records = payload.get('records', [])
    except Exception as e:
        return jsonify({"error": "Could not fetch data from data.gov.in", "details": str(e)}), 500

    # Filter records for Tamil Nadu if dataset contains state field
    tn_records = []
    for rec in records:
        if any(key in rec and rec[key] and 'tamil' in str(rec[key]).lower() for key in ['state', 'State', 'state_name', 'State / UT']):
            tn_records.append(rec)
    if not tn_records:
        tn_records = records

    out = []
    for rcd in tn_records:
        year = rcd.get('Year') or rcd.get('year') or rcd.get('Financial Year') or rcd.get('fy') or rcd.get('fiscal_year')
        value = None
        for k in ['Amount', 'amount', 'Value', 'value', 'Total', 'total', 'Revenue', 'revenue']:
            if k in rcd and rcd[k]:
                try:
                    val = float(str(rcd[k]).replace(',','').strip())
                    value = val
                    break
                except:
                    continue
        out.append({"raw": rcd, "year": year, "value": value})
    return jsonify(out)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
