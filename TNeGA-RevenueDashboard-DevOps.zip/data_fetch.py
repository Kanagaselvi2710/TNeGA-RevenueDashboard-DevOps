
# Helper functions (optional)
import os, requests
API_KEY = os.environ.get('DATA_GOV_API_KEY', '')
RESOURCE_ID = "14613c4e-5ab0-4705-b440-e4e49ae345de"
BASE_URL = f"https://api.data.gov.in/resource/{RESOURCE_ID}"

def fetch_records(limit=200):
    params = {
        "api-key": API_KEY,
        "format": "json",
        "limit": limit
    }
    r = requests.get(BASE_URL, params=params, timeout=20)
    r.raise_for_status()
    return r.json().get('records', [])
